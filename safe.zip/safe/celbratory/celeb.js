const targetDate = new Date("September 18, 2026 08:00:00").getTime();

const second = document.getElementById("seconds");
const minute = document.getElementById("minutes");
const hours = document.getElementById("hours");
const days = document.getElementById("days");

function updateCountdown() {

    const now = new Date().getTime();

    const difference = targetDate - now;

    const days = Math.floor(difference / (1000 * 60 * 60 * 24));

    const hours = Math.floor(
        (difference % (1000 * 60 * 60 * 24)) /
        (1000 * 60 * 60)
    );

    const minutes = Math.floor(
        (difference % (1000 * 60 * 60)) /
        (1000 * 60)
    );

    const seconds = Math.floor(
        (difference % (1000 * 60)) /
        1000
    );

    days.textContent = days;
    hours.textContent = hours;
    minutes.textContent = minutes;
    seconds.textContent = seconds;
}

setInterval(updateCountdown, 1000);

updateCountdown();